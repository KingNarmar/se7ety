import 'package:flutter/material.dart';
import 'package:flutter_svg/flutter_svg.dart';
import 'package:gap/gap.dart';
import 'package:se7ety/core/constants/app_images.dart';
import 'package:se7ety/core/styles/app_colors.dart';
import 'package:se7ety/core/styles/text_styles.dart';
import 'package:se7ety/core/widgets/custom_text_form_field.dart';
import 'package:se7ety/features/home/presentation/widgets/specialty_card.dart';

class PatientHomeScreen extends StatelessWidget {
  const PatientHomeScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text("صــحّـتـي", style: TextStyles.w700s25),
        centerTitle: true,
        actions: [
          IconButton(
            onPressed: () {},
            icon: SvgPicture.asset(AppImages.notificationsIconSvg, height: 25),
          ),
        ],
      ),
      body: Padding(
        padding: const EdgeInsets.all(20),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,

          children: [
            Text("مرحبا,", style: TextStyles.w500s25),
            Gap(10),
            Text(
              "احجز الآن وكن جزءًا من رحلتك الصحية.",
              style: TextStyles.w700s25,
            ),
            Gap(20),
            CustomTextFormField(
              hintText: "ابحث عن طبيب أو تخصص",
              prefixIcon: const Icon(Icons.search),
            ),
            Gap(20),
            Text(
              "التخصصات",
              style: TextStyles.w700s25.copyWith(color: AppColors.primaryColor),
            ),

            Gap(20),
            SpecialtyCard(
              title: "جراحه عامه",
              imagePath: AppImages.specialty1Svg,
              bgColor: const Color(0xff71B4FB),
            ),
            // Container(
            //   decoration: BoxDecoration(
            //     borderRadius: BorderRadius.circular(20),
            //     color: Color(0xff71B4FB),
            //   ),
            //   child: Padding(
            //     padding: const EdgeInsets.all(20),
            //     child: Column(
            //       children: [
            //         SvgPicture.asset(AppImages.specialty1Svg, height: 100),
            //         Gap(10),
            //         Text(
            //           "جراحه عامه",
            //           style: TextStyles.w700s25.copyWith(color: Colors.white),
            //         ),
            //       ],
            //     ),
            //   ),
            // ),
          ],
        ),
      ),
    );
  }
}
