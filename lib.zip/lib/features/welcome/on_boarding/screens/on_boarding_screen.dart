import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:flutter_svg/flutter_svg.dart';
import 'package:gap/gap.dart';
import 'package:se7ety/core/styles/app_colors.dart';
import 'package:se7ety/core/styles/text_styles.dart';
import 'package:se7ety/core/widgets/app_button.dart';
import 'package:se7ety/features/welcome/on_boarding/cubit/on_boarding_cubit.dart';

class OnBoardingScreen extends StatefulWidget {
  const OnBoardingScreen({super.key});

  @override
  State<OnBoardingScreen> createState() => _OnBoardingScreenState();
}

class _OnBoardingScreenState extends State<OnBoardingScreen> {
  late PageController _pageController;

  @override
  void initState() {
    super.initState();
    _pageController = PageController();
  }

  @override
  void dispose() {
    _pageController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: SafeArea(
        child: BlocBuilder<OnBoardingCubit, OnBoardingState>(
          builder: (context, state) {
            final cubit = context.read<OnBoardingCubit>();

            return Padding(
              padding: const EdgeInsets.all(20),
              child: Column(
                children: [
                  // PageView for Onboarding contents
                  Expanded(
                    child: PageView.builder(
                      controller: _pageController,
                      itemCount: cubit.totalPages,
                      onPageChanged: (index) {
                        cubit.onPageChanged(index);
                      },
                      itemBuilder: (context, index) {
                        final page = cubit.pages[index];
                        return _OnboardingPageContent(page: page);
                      },
                    ),
                  ),
                  const Gap(20),
                  // Bottom Area: Indicator & Primary Button
                  Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      _OnboardingIndicator(cubit: cubit),
                      AppButton(
                        text: cubit.isLastPage ? "هيا بنا !" : "التالي",
                        textStyle: TextStyles.w400s25.copyWith(
                          color: Colors.white,
                        ),
                        borderRadius: 20,
                        onPressed: () {
                          if (cubit.isLastPage) {
                            // Uncomment context.pushReplacement when builder for /login is ready.
                            // context.pushReplacement(AppRoutes.login);
                          } else {
                            _pageController.nextPage(
                              duration: const Duration(milliseconds: 300),
                              curve: Curves.easeInOut,
                            );
                          }
                        },
                      ),
                    ],
                  ),
                ],
              ),
            );
          },
        ),
      ),
    );
  }
}

class _OnboardingPageContent extends StatelessWidget {
  final OnBoardingModel page;

  const _OnboardingPageContent({required this.page});

  @override
  Widget build(BuildContext context) {
    return Column(
      mainAxisAlignment: MainAxisAlignment.center,
      children: [
        SvgPicture.asset(page.image, height: 300),
        const Gap(30),
        Text(
          page.title,
          textAlign: TextAlign.center,
          style: TextStyles.w500s25.copyWith(
            color: AppColors.primaryColor,
            fontWeight: FontWeight.w700,
          ),
        ),
        const Gap(15),
        Text(
          page.body,
          textAlign: TextAlign.center,
          style: const TextStyle(fontSize: 16, color: AppColors.borderColor),
        ),
      ],
    );
  }
}

class _OnboardingIndicator extends StatelessWidget {
  final OnBoardingCubit cubit;

  const _OnboardingIndicator({required this.cubit});

  @override
  Widget build(BuildContext context) {
    return Row(
      mainAxisSize: MainAxisSize.min,
      children: List.generate(
        cubit.totalPages,
        (index) => AnimatedContainer(
          duration: const Duration(milliseconds: 300),
          margin: const EdgeInsetsDirectional.only(end: 5),
          height: 10,
          width: cubit.currentPage == index ? 30 : 10,
          decoration: BoxDecoration(
            color: cubit.currentPage == index
                ? AppColors.primaryColor
                : AppColors.secondaryColor,
            borderRadius: BorderRadius.circular(10),
          ),
        ),
      ),
    );
  }
}
